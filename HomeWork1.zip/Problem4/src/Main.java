import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("How much numbers do u want in the array?");
        int hm = Integer.parseInt(reader.readLine());
        int[] mass = new int[hm];
        System.out.println("Please input your numbers in different lines");
        for (int i = 0; i < hm; i++) {
            mass[i] = (Integer.parseInt(reader.readLine()));
        }
        BubbleSort(mass);
        for (int j : mass) {
            System.out.print(j + " ");
        }

    }
    public static void BubbleSort(int[] mass) {

        for (int i = 0; i < mass.length; i++){
            for (int j = 1; j < mass.length - i; j++){
                if (mass[j - 1] > mass[j]){
                    int k = mass[j - 1];
                    mass[j - 1] = mass[j];
                    mass[j] = k;
                }
            }
        }
    }


}