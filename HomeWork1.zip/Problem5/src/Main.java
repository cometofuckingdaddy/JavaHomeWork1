import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String line = reader.readLine();
        Counter(line);
    }

    public static void Counter(String line) {
        int count = 0;
        int countVowels = 0;
        int countCons = 0;
        for (int i = 0; i < line.length(); i++) {
            if ((line.charAt(i) >= 'A' && line.charAt(i) < 'Z') || (line.charAt(i) >= 'a' && line.charAt(i) < 'z')) {
                count++;
                if (line.charAt(i) == 'A' || line.charAt(i) == 'E' || line.charAt(i) == 'I'
                        || line.charAt(i) == 'O' || line.charAt(i) == 'U' || line.charAt(i) == 'Y' ||
                        line.charAt(i) == 'a' || line.charAt(i) == 'e' || line.charAt(i) == 'i'
                        || line.charAt(i) == 'o' || line.charAt(i) == 'u' || line.charAt(i) == 'y') {
                        countVowels++;
                }
            }
        }
        countCons = count - countVowels;
        System.out.println("Count of vowels = " + countVowels);
        System.out.println("Count of consonants = " + countCons);
    }
}