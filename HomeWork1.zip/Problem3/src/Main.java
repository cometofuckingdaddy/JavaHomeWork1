import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int N = Integer.parseInt(reader.readLine());
        System.out.print(Factrial(N));

    }
    public static int Factrial(int N) {
        if (N < 0) {
            System.out.print("Incorrect input");
            System.exit(0);
        }
        if (N == 0) {
            return 1;
        } else {
            return  N * Factrial(N - 1);
        }
    }
}