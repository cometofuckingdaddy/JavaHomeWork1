import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int N = Integer.parseInt(reader.readLine());
        Fib(N);
    }
    public static void Fib(int N) {
        int[] fib = new int[N];
        fib[0] = 1;
        fib[1] = 1;
        for (int i = 2; i < N; ++i) {
            fib[i] = fib[i - 1] + fib[i - 2];
        }
        for (int j : fib) {
            System.out.println(j);
        }
    }
}